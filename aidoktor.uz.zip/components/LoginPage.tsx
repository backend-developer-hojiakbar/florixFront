import React, { useState } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import LockIcon from '@/assets/icons/LockIcon';
import AdPlaceholder from '@/components/AdPlaceholder';

const LoginPage = ({ onLoginSuccess, onNavigateToRegister, onBack }) => {
  const { t, t_noDynamic } = useTranslation();
  const [identifier, setIdentifier] = useState(''); // Can be email or username
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    setError('');
    if (!identifier || !password) {
      setError(t_noDynamic('fieldRequired')); 
      return;
    }
    
    console.log('Mock Login Attempt:', { identifier, password });
    
    let username = identifier;
    if (identifier.includes('@')) {
        username = identifier.split('@')[0];
    }
    username = username.charAt(0).toUpperCase() + username.slice(1);

    onLoginSuccess({ username: username, email: identifier.includes('@') ? identifier : undefined });
  };

  return (
    <>
      <div className="max-w-md mx-auto p-6 md:p-10 shadow-2xl rounded-lg bg-gradient-to-b from-teal-50/80 to-cyan-50/70 backdrop-blur-md text-slate-800">
        <div className="text-center mb-8">
          <LockIcon className="w-16 h-16 mx-auto mb-4 text-sky-500" title={t_noDynamic('loginLockIconTitle')} />
          <h2 className="text-3xl font-bold uppercase text-slate-800">{t_noDynamic('loginTitle')}</h2>
        </div>
        
        <AdPlaceholder 
            adType="banner_320x50" 
            className="w-full mb-6" 
            titleText={t_noDynamic('adPlaceholderLogin')}
        />

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label htmlFor="identifier" className="block text-sm font-medium text-slate-600 mb-1">
              {t_noDynamic('loginEmailLabel')}
            </label>
            <input
              type="text"
              id="identifier"
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              placeholder={t_noDynamic('loginEmailPlaceholder')}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none border-slate-300/80 bg-white/90 text-slate-800 placeholder-slate-500"
              required
              aria-label={t_noDynamic('loginEmailLabel')}
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-slate-600 mb-1">
              {t_noDynamic('loginPasswordLabel')}
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={t_noDynamic('loginPasswordPlaceholder')}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none border-slate-300/80 bg-white/90 text-slate-800 placeholder-slate-500"
              required
              aria-label={t_noDynamic('loginPasswordLabel')}
            />
          </div>

          {error && <p className="text-sm text-red-500 text-center" role="alert">{error}</p>}

          <button
            type="submit"
            className="w-full p-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg transition-colors uppercase"
          >
            {t_noDynamic('loginButton')}
          </button>
        </form>
        
        <p className="text-center mt-6 text-sm text-slate-500">
          {t_noDynamic('loginNoAccount')}{' '}
          <button onClick={onNavigateToRegister} className="font-medium text-sky-600 hover:text-sky-700 underline">
            {t_noDynamic('loginRegisterNow')}
          </button>
        </p>
      </div>
      <button
        onClick={onBack}
        className="flex items-center justify-center mx-auto space-x-2 text-base py-3 px-5 rounded-lg transition-colors uppercase text-sky-600 hover:text-sky-700 hover:bg-sky-100/70 backdrop-blur-sm mt-8 border border-sky-500 hover:border-sky-600 w-full max-w-xs"
        aria-label={t_noDynamic('backToMainMenuButton')}
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
          <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
        </svg>
        <span>{t_noDynamic('mainMenuButton')}</span>
      </button>
    </>
  );
};

export default LoginPage;