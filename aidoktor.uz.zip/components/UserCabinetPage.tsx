import React, { useState } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
// import { User } from '@/types'; // Interface removed from here, assume User type is available globally or implicitly through currentUser prop
import UserIcon from '@/assets/icons/UserIcon';
import LogoutIcon from '@/assets/icons/LogoutIcon';
import HistoryIcon from '@/assets/icons/HistoryIcon';
import DocumentTextIcon from '@/assets/icons/DocumentTextIcon';
import PillIcon from '@/assets/icons/PillIcon';
import SettingsIcon from '@/assets/icons/SettingsIcon';
import AdPlaceholder from '@/components/AdPlaceholder';
import FeatureComingSoonModal from '@/components/FeatureComingSoonModal';

// Mock User type, replace with actual type from '@/types' if defined there
// For now, assuming currentUser can have these optional fields:
// interface CurrentUser {
//   username: string;
//   email?: string;
//   fullName?: string;
//   dob?: string;
//   gender?: string;
//   phone?: string;
//   allergies?: string;
//   chronicDiseases?: string;
// }


// interface UserCabinetPageProps {
//   currentUser: CurrentUser | null;
//   onLogout: () => void;
//   onBack: () => void;
// }

// type CabinetSection = 'profile' | 'diagnosisHistory' | 'analysisReports' | 'drugLookups' | 'settings' | 'myMedications';

const UserCabinetPage = ({ currentUser, onLogout, onBack }) => {
  const { t, t_noDynamic } = useTranslation();
  const [activeSection, setActiveSection] = useState('profile');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isFeatureModalOpen, setIsFeatureModalOpen] = useState(false);

  const handleFeatureComingSoon = () => {
    setIsFeatureModalOpen(true);
  };

  const handleDeleteAccount = () => {
    setShowDeleteConfirm(true);
  };

  const confirmDeleteAccount = () => {
    setShowDeleteConfirm(false);
    handleFeatureComingSoon(); 
  };

  if (!currentUser) {
    return (
      <div className="max-w-2xl mx-auto p-6 md:p-10 shadow-2xl rounded-lg text-center bg-white/80 backdrop-blur-md text-slate-800">
        <p className="text-red-500">{t_noDynamic('userCabinetErrorUserNotFound')}</p>
        <button
            onClick={onBack}
            className="flex items-center justify-center mx-auto space-x-2 text-base py-3 px-5 rounded-lg transition-colors uppercase text-sky-600 hover:text-sky-700 hover:bg-sky-100/70 backdrop-blur-sm mt-8 border border-sky-500 hover:border-sky-600 w-full max-w-xs"
            aria-label={t_noDynamic('backToMainMenuButton')}
        >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
            </svg>
            <span>{t_noDynamic('mainMenuButton')}</span>
        </button>
      </div>
    );
  }
  
  const ProfileFieldDisplay = ({ labelKey, value, placeholderKey, isTextarea = false }) => (
    <div className="mb-4">
      <label className="block text-sm font-medium text-slate-500 mb-1">{t_noDynamic(labelKey)}:</label>
      {isTextarea ? (
        <textarea
          readOnly
          value={value || ''}
          placeholder={t_noDynamic(placeholderKey || 'compAnalysisNoAnswer')}
          className="w-full p-2.5 border rounded-lg outline-none border-slate-300/80 bg-purple-50/60 text-slate-700 placeholder-slate-400 min-h-[80px]"
          rows={3}
        />
      ) : (
        <input
          type="text"
          readOnly
          value={value || ''}
          placeholder={t_noDynamic(placeholderKey || 'compAnalysisNoAnswer')}
          className="w-full p-2.5 border rounded-lg outline-none border-slate-300/80 bg-purple-50/60 text-slate-700 placeholder-slate-400"
        />
      )}
    </div>
  );


  const renderSectionContent = () => {
    switch (activeSection) {
      case 'profile':
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-purple-600 uppercase">{t_noDynamic('userCabinetProfileSectionTitle')}</h3>
            <div className="bg-purple-50/50 backdrop-blur-xs p-4 sm:p-6 rounded-lg shadow border border-purple-200/70">
              <ProfileFieldDisplay labelKey="userCabinetProfileUsername" value={currentUser.username} placeholderKey="compAnalysisNoAnswer" />
              <ProfileFieldDisplay labelKey="userCabinetProfileEmail" value={currentUser.email} placeholderKey="compAnalysisNoAnswer" />
              <ProfileFieldDisplay labelKey="userCabinetProfileFullName" value={currentUser.fullName} placeholderKey="comingSoonText"/>
              <ProfileFieldDisplay labelKey="userCabinetProfileDob" value={currentUser.dob} placeholderKey="comingSoonText"/>
              <ProfileFieldDisplay labelKey="userCabinetProfileGender" value={currentUser.gender} placeholderKey="comingSoonText"/>
              <ProfileFieldDisplay labelKey="userCabinetProfilePhone" value={currentUser.phone} placeholderKey="comingSoonText"/>
              <ProfileFieldDisplay labelKey="userCabinetProfileAllergies" value={currentUser.allergies} placeholderKey="userCabinetProfileAllergiesPlaceholder" isTextarea />
              <ProfileFieldDisplay labelKey="userCabinetProfileChronicDiseases" value={currentUser.chronicDiseases} placeholderKey="userCabinetProfileChronicDiseasesPlaceholder" isTextarea />
            </div>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                <button onClick={handleFeatureComingSoon} className="flex-1 py-2.5 px-4 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-md transition-colors uppercase text-sm">
                    {t_noDynamic('userCabinetProfileEditButton')}
                </button>
                <button onClick={handleFeatureComingSoon} className="flex-1 py-2.5 px-4 bg-orange-500 hover:bg-orange-600 text-white font-medium rounded-md transition-colors uppercase text-sm">
                    {t_noDynamic('userCabinetProfileChangePasswordButton')}
                </button>
            </div>
          </div>
        );
      case 'myMedications':
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-purple-600 uppercase">{t_noDynamic('userCabinetMyMedications')}</h3>
            <div className="bg-purple-50/50 backdrop-blur-xs p-4 sm:p-6 rounded-lg shadow border border-purple-200/70 min-h-[150px] flex flex-col items-center justify-center">
              <p className="text-slate-500 italic mb-4">{t_noDynamic('userCabinetMyMedicationsEmpty')}</p>
              <button onClick={handleFeatureComingSoon} className="py-2.5 px-4 bg-green-500 hover:bg-green-600 text-white font-medium rounded-md transition-colors uppercase text-sm">
                  {t_noDynamic('userCabinetAddMedicationReminder')}
              </button>
            </div>
          </div>
        );
      case 'diagnosisHistory':
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-purple-600 uppercase">{t_noDynamic('userCabinetDiagnosisHistoryTitle')}</h3>
            <div className="bg-purple-50/50 backdrop-blur-xs p-4 sm:p-6 rounded-lg shadow border border-purple-200/70 min-h-[200px] flex items-center justify-center">
                <p className="text-slate-500 italic">{t_noDynamic('userCabinetDiagnosisHistoryEmpty')}</p>
            </div>
          </div>
        );
      case 'analysisReports':
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-purple-600 uppercase">{t_noDynamic('userCabinetAnalysisReportsTitle')}</h3>
             <div className="bg-purple-50/50 backdrop-blur-xs p-4 sm:p-6 rounded-lg shadow border border-purple-200/70 min-h-[200px] flex items-center justify-center">
                <p className="text-slate-500 italic">{t_noDynamic('userCabinetAnalysisReportsEmpty')}</p>
            </div>
          </div>
        );
      case 'drugLookups':
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-purple-600 uppercase">{t_noDynamic('userCabinetDrugLookupsTitle')}</h3>
             <div className="bg-purple-50/50 backdrop-blur-xs p-4 sm:p-6 rounded-lg shadow border border-purple-200/70 min-h-[200px] flex items-center justify-center">
                <p className="text-slate-500 italic">{t_noDynamic('userCabinetDrugLookupsEmpty')}</p>
            </div>
          </div>
        );
      case 'settings':
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-purple-600 uppercase">{t_noDynamic('userCabinetSettingsTitle')}</h3>
            <div className="bg-purple-50/50 backdrop-blur-xs p-4 sm:p-6 rounded-lg shadow border border-purple-200/70">
                <div className="mb-4">
                    <label className="block font-medium text-slate-600 mb-1">{t_noDynamic('userCabinetSettingsNotifications')}</label>
                    <div className="space-y-2">
                        <label className="flex items-center space-x-2 cursor-pointer">
                            <input type="checkbox" className="form-checkbox h-5 w-5 text-sky-600 bg-white/80 border-slate-400/80 rounded focus:ring-sky-500" onChange={handleFeatureComingSoon} />
                            <span className="text-slate-700">{t_noDynamic('userCabinetSettingsEmailNotifications')}</span>
                        </label>
                        <label className="flex items-center space-x-2 cursor-pointer">
                            <input type="checkbox" className="form-checkbox h-5 w-5 text-sky-600 bg-white/80 border-slate-400/80 rounded focus:ring-sky-500" onChange={handleFeatureComingSoon} />
                            <span className="text-slate-700">{t_noDynamic('userCabinetSettingsPushNotifications')}</span>
                        </label>
                    </div>
                </div>
                 <div className="mb-4">
                    <label htmlFor="languageSelect" className="block font-medium text-slate-600 mb-1">{t_noDynamic('userCabinetSettingsLanguage')}</label>
                    <select id="languageSelect" className="w-full p-2.5 bg-white/90 border-slate-300/80 text-slate-700 rounded-md focus:ring-sky-500 focus:border-sky-500" disabled>
                        <option>{t_noDynamic('languageUzbekOnly')}</option>
                    </select>
                </div>
                <div className="mb-6">
                    <label htmlFor="themeSelect" className="block font-medium text-slate-600 mb-1">{t_noDynamic('userCabinetSettingsTheme')}</label>
                    <select id="themeSelect" className="w-full p-2.5 bg-white/90 border-slate-300/80 text-slate-700 rounded-md focus:ring-sky-500 focus:border-sky-500" disabled>
                        <option>{t_noDynamic('userCabinetSettingsThemeDark')} {/* Will be 'Light Theme' based on global styles */}</option>
                    </select>
                </div>
                <button 
                    onClick={handleDeleteAccount} 
                    className="w-full py-2.5 px-4 bg-red-600 hover:bg-red-700 text-white font-medium rounded-md transition-colors uppercase text-sm"
                >
                    {t_noDynamic('userCabinetSettingsDeleteAccountButton')}
                </button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };
  
  const NavItem = ({ label, icon, isActive, onClick }) => (
    <button
      onClick={onClick}
      className={`flex items-center space-x-3 w-full text-left px-3 py-3 rounded-md transition-colors text-sm font-medium
                  ${isActive 
                    ? 'bg-purple-500 text-white shadow-md' 
                    : 'text-slate-700 hover:bg-purple-200/70 hover:text-purple-700'
                  }`}
      aria-current={isActive ? 'page' : undefined}
    >
      {icon}
      <span>{label}</span>
    </button>
  );


  return (
    <>
      <FeatureComingSoonModal isOpen={isFeatureModalOpen} onClose={() => setIsFeatureModalOpen(false)} />
      <div className="max-w-5xl mx-auto p-4 md:p-6 shadow-2xl rounded-lg bg-gradient-to-b from-fuchsia-50/80 to-violet-50/70 backdrop-blur-md text-slate-800">
        <div className="text-center mb-6">
            <UserIcon className="w-16 h-16 mx-auto mb-3 text-purple-500" title={t_noDynamic('userCabinetUserIconTitle')} />
            <h2 className="text-2xl md:text-3xl font-bold uppercase text-slate-800">{t_noDynamic('userCabinetTitle')}</h2>
            <p className="text-md md:text-lg text-slate-600 mt-1">{t('userCabinetWelcome', { username: currentUser.username })}</p>
        </div>
        
        <AdPlaceholder 
            adType="banner_468x60" 
            className="w-full mb-6"
            titleText={t_noDynamic('adPlaceholderCabinetSection')}
        />

        <div className="flex flex-col md:flex-row gap-6 md:gap-8">
          <aside className="md:w-1/4 lg:w-1/5 flex-shrink-0">
            <nav className="space-y-2 p-3 bg-purple-100/60 backdrop-blur-sm rounded-lg shadow border border-purple-200/70">
              <NavItem 
                label={t_noDynamic('userCabinetNavProfile')} 
                icon={<UserIcon className="w-5 h-5" />} 
                isActive={activeSection === 'profile'} 
                onClick={() => setActiveSection('profile')} 
              />
               <NavItem 
                label={t_noDynamic('userCabinetMyMedications')} 
                icon={<PillIcon className="w-5 h-5 text-emerald-600" />} 
                isActive={activeSection === 'myMedications'} 
                onClick={() => setActiveSection('myMedications')}
              />
              <NavItem 
                label={t_noDynamic('userCabinetNavDiagnosisHistory')} 
                icon={<HistoryIcon className="w-5 h-5" />} 
                isActive={activeSection === 'diagnosisHistory'} 
                onClick={() => { setActiveSection('diagnosisHistory'); handleFeatureComingSoon();}} 
              />
              <NavItem 
                label={t_noDynamic('userCabinetNavAnalysisReports')} 
                icon={<DocumentTextIcon className="w-5 h-5" />} 
                isActive={activeSection === 'analysisReports'} 
                onClick={() => { setActiveSection('analysisReports'); handleFeatureComingSoon();}}
              />
              <NavItem 
                label={t_noDynamic('userCabinetNavDrugLookups')} 
                icon={<PillIcon className="w-5 h-5" />} 
                isActive={activeSection === 'drugLookups'} 
                onClick={() => { setActiveSection('drugLookups'); handleFeatureComingSoon();}}
              />
              <NavItem 
                label={t_noDynamic('userCabinetNavSettings')} 
                icon={<SettingsIcon className="w-5 h-5" />} 
                isActive={activeSection === 'settings'} 
                onClick={() => setActiveSection('settings')} 
              />
            </nav>
          </aside>

          <main className="flex-1 p-4 md:p-6 bg-white/70 backdrop-blur-sm rounded-lg shadow-inner border border-slate-200/80 min-h-[300px]">
            {renderSectionContent()}
          </main>
        </div>
        
        <div className="mt-8 text-center">
            <button
                onClick={onLogout}
                className="inline-flex items-center justify-center space-x-2 py-2.5 px-6 bg-red-500 hover:bg-red-600 text-white font-semibold rounded-lg transition-colors uppercase text-sm shadow-md hover:shadow-lg"
                aria-label={t_noDynamic('userCabinetLogoutButton')}
            >
                <LogoutIcon className="w-5 h-5" />
                <span>{t_noDynamic('userCabinetLogoutButton')}</span>
            </button>
        </div>
      </div>

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-md flex items-center justify-center z-50 p-4" role="dialog" aria-modal="true" aria-labelledby="deleteAccountConfirmTitle">
          <div className="bg-white/95 backdrop-blur-sm p-6 rounded-lg shadow-xl max-w-sm w-full text-slate-800">
            <h3 id="deleteAccountConfirmTitle" className="text-lg font-semibold text-slate-800 mb-4">{t_noDynamic('confirmAction')}</h3>
            <p className="text-slate-600 mb-6 text-sm">{t_noDynamic('deleteAccountConfirmation')}</p>
            <div className="flex justify-end space-x-3">
              <button 
                onClick={() => setShowDeleteConfirm(false)} 
                className="py-2 px-4 bg-slate-200/80 hover:bg-slate-300/90 text-slate-700 rounded-md text-sm uppercase"
              >
                {t_noDynamic('cancelButton')}
              </button>
              <button 
                onClick={confirmDeleteAccount} 
                className="py-2 px-4 bg-red-500 hover:bg-red-600 text-white rounded-md text-sm uppercase"
              >
                {t_noDynamic('confirmButton')}
              </button>
            </div>
          </div>
        </div>
      )}

      <button
        onClick={onBack}
        className="flex items-center justify-center mx-auto space-x-2 text-base py-3 px-5 rounded-lg transition-colors uppercase text-sky-600 hover:text-sky-700 hover:bg-sky-100/70 backdrop-blur-sm mt-8 border border-sky-500 hover:border-sky-600 w-full max-w-xs"
        aria-label={t_noDynamic('backToMainMenuButton')}
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
          <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
        </svg>
        <span>{t_noDynamic('mainMenuButton')}</span>
      </button>
    </>
  );
};

export default UserCabinetPage;