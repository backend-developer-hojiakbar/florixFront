













import React, { useState, useEffect, useCallback } from 'react';
import { AppMode } from '@/types'; 
import QuickDiagnosisMode from '@/components/QuickDiagnosisMode';
import ComprehensiveAnalysisMode from '@/components/ComprehensiveAnalysisMode';
import HealthLibraryMode from '@/components/HealthLibraryMode';
import PhysiotherapyMode from '@/components/PhysiotherapyMode';
import CallCenterMode from '@/components/CallCenterMode';
import OnLabMode from '@/components/OnLabMode'; 
import { DrugIdentifierMode } from '@/components/DrugIdentifierMode';
import { FirstAidMode } from '@/components/FirstAidMode';
import LoginPage from '@/components/LoginPage';
import { RegisterPage } from '@/components/RegisterPage'; 
import UserCabinetPage from '@/components/UserCabinetPage';
// import HealthTrackerMode from '@/components/HealthTrackerMode'; // Removed
import Header from '@/components/Header';
import AdPlaceholder from '@/components/AdPlaceholder';
import { useTranslation } from '@/hooks/useTranslation';
import MicroscopeIcon from '@/assets/icons/MicroscopeIcon'; 
import PillIcon from '@/assets/icons/PillIcon'; 
import FirstAidIcon from '@/assets/icons/FirstAidIcon';
import IdleTimerIcon from '@/assets/icons/IdleTimerIcon';
import LockIcon from '@/assets/icons/LockIcon';
// import HealthTrackerIcon from '@/assets/icons/HealthTrackerIcon'; // Removed
import ShareIcon from '@/assets/icons/ShareIcon'; 
import FeedbackIcon from '@/assets/icons/FeedbackIcon'; 
import StartIcon from '@/assets/icons/StartIcon';

// --- TypeScript Global Augmentation for Telegram WebApp ---
declare global {
  interface Window {
    Telegram?: {
      WebApp: {
        ready: () => void;
        expand: () => void;
        setHeaderColor: (colorKey: string) => void; 
        setBackgroundColor: (color: string) => void; // Added for main background
        themeParams: {
          bg_color?: string;
          secondary_bg_color?: string;
          text_color?: string;
          hint_color?: string;
          link_color?: string;
          button_color?: string;
          button_text_color?: string;
          // Add other themeParams properties if used
        };
        BackButton: {
          show: () => void;
          hide: () => void;
          onClick: (callback: () => void) => void;
          offClick: (callback: () => void) => void;
          isVisible: boolean;
        };
        // Functions for sharing and external links
        openTelegramLink: (url: string) => void;
        openLink: (url: string) => void; // Added for opening external links
        // Optional: Define onEvent if you plan to use it
        // onEvent: (eventType: string, eventHandler: () => void) => void;
      };
    };
  }
}
// --- End TypeScript Global Augmentation ---


// --- Sub-components defined within App.jsx for brevity ---

const PrivacyPolicyModal = ({ onClose }) => {
  const { t_noDynamic } = useTranslation();
  const effectiveDate = "2024-07-28"; 

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-md flex items-center justify-center z-50 p-4 animate-fadeInScaleUp" role="dialog" aria-modal="true" aria-labelledby="privacyPolicyTitle">
      <div className="bg-white/95 backdrop-blur-sm p-6 rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto custom-scrollbar text-slate-800">
        <div className="flex justify-between items-center mb-4">
          <h2 id="privacyPolicyTitle" className="text-xl font-bold text-sky-600 uppercase">{t_noDynamic('privacyPolicyTitle')}</h2>
          <button onClick={onClose} className="text-slate-600 hover:text-slate-900" aria-label={t_noDynamic('closePrivacyPolicyPopup')}>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-7 h-7">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <p className="text-xs text-slate-500 mb-4">{t_noDynamic('effectiveDateLabel')}: {effectiveDate}</p>
        <div className="space-y-4 text-sm text-slate-700 prose prose-sm max-w-none prose-slate">
          <p>{t_noDynamic('privacyPolicyP1')}</p>
          
          <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('privacyPolicyH1')}</h3>
          <ul className="list-disc list-inside space-y-1 pl-4" dangerouslySetInnerHTML={{ __html: t_noDynamic('privacyPolicyL1') }}></ul>
          
          <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('privacyPolicyH2')}</h3>
          <p>{t_noDynamic('privacyPolicyP2')}</p>
          <ul className="list-disc list-inside space-y-1 pl-4" dangerouslySetInnerHTML={{ __html: t_noDynamic('privacyPolicyL2') }}></ul>
          <p>{t_noDynamic('privacyPolicyP3')}</p>

          <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('privacyPolicyH3')}</h3>
          <p>{t_noDynamic('privacyPolicyP4')}</p>

          <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('privacyPolicyH4')}</h3>
          <p>{t_noDynamic('privacyPolicyP5')}</p>

          <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('privacyPolicyH5')}</h3>
          <p>{t_noDynamic('privacyPolicyP6')}</p>

          <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('privacyPolicyH6')}</h3>
          <p>{t_noDynamic('privacyPolicyP7')}</p>

          <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('privacyPolicyH7')}</h3>
          <p>{t_noDynamic('privacyPolicyP8')}</p>

          <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('privacyPolicyH8')}</h3>
          <p>{t_noDynamic('privacyPolicyP9')}</p>
        </div>
        <button
            onClick={onClose}
            className="mt-6 w-full bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2.5 px-5 rounded-lg transition-colors uppercase"
            aria-label={t_noDynamic('closePrivacyPolicyPopup')}
        >
            {t_noDynamic('understoodButton')}
        </button>
      </div>
    </div>
  );
};

const TermsOfUseModal = ({ onClose }) => {
  const { t_noDynamic } = useTranslation();
  const effectiveDate = "2024-07-28"; 

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-md flex items-center justify-center z-50 p-4 animate-fadeInScaleUp" role="dialog" aria-modal="true" aria-labelledby="termsOfUseTitleModal">
      <div className="bg-white/95 backdrop-blur-sm p-6 rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto custom-scrollbar text-slate-800">
        <div className="flex justify-between items-center mb-4">
            <h2 id="termsOfUseTitleModal" className="text-xl font-bold text-sky-600 uppercase">{t_noDynamic('termsOfUseTitle')}</h2>
            <button onClick={onClose} className="text-slate-600 hover:text-slate-900" aria-label={t_noDynamic('closeTermsOfUsePopup')}>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-7 h-7">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        <p className="text-xs text-slate-500 mb-4">{t_noDynamic('effectiveDateLabel')}: {effectiveDate}</p>
        <div className="space-y-4 text-sm text-slate-700 prose prose-sm max-w-none prose-slate">
            <p>{t_noDynamic('termsP1')}</p>

            <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('termsH1')}</h3>
            <p>{t_noDynamic('termsP2')}</p>

            <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('termsH2')}</h3>
            <ul className="list-disc list-inside space-y-1 pl-4" dangerouslySetInnerHTML={{ __html: t_noDynamic('termsL1') }}></ul>
            
            <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('termsH3')}</h3>
            <p>{t_noDynamic('termsP3')}</p>

            <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('termsH4')}</h3>
            <p>{t_noDynamic('termsP4')}</p>

            <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('termsH5')}</h3>
            <p>{t_noDynamic('termsP5')}</p>

            <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('termsH6')}</h3>
            <p>{t_noDynamic('termsP6')}</p>

            <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('termsH7')}</h3>
            <p>{t_noDynamic('termsP7')}</p>

            <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('termsH8')}</h3>
            <p>{t_noDynamic('termsP8')}</p>

            <h3 className="text-md font-semibold text-sky-700 pt-2">{t_noDynamic('termsH9')}</h3>
            <p>{t_noDynamic('termsP9')}</p>
        </div>
        <button
            onClick={onClose}
            className="mt-6 w-full bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2.5 px-5 rounded-lg transition-colors uppercase"
            aria-label={t_noDynamic('closeTermsOfUsePopup')}
        >
            {t_noDynamic('understoodButton')}
        </button>
      </div>
    </div>
  );
};

const WarningModal = ({ onAgree, onShowPrivacy, onShowTerms }) => {
  const { t_noDynamic } = useTranslation();
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-lg flex items-center justify-center z-50 p-4 animate-fadeInScaleUp" role="dialog" aria-modal="true" aria-labelledby="warningTitleModal">
      <div className="bg-gradient-to-br from-rose-100 via-orange-50 to-amber-100/90 p-6 rounded-xl shadow-2xl max-w-xl w-full backdrop-blur-sm max-h-[90vh] overflow-y-auto custom-scrollbar">
        <h2 id="warningTitleModal" className="text-2xl font-bold text-red-600 mb-4 text-center uppercase">{t_noDynamic('warningTitle')}</h2>
        <div className="text-slate-700 mb-3 text-sm prose prose-sm max-w-none prose-slate" dangerouslySetInnerHTML={{ __html: t_noDynamic('warningP1') }} />
        <p className="text-slate-700 mb-6 text-sm">
            {t_noDynamic('warningP2preLink')}{' '}
            <button onClick={onShowTerms} className="underline text-sky-600 hover:text-sky-700">{t_noDynamic('termsOfUseLink')}</button>{' '}
            {t_noDynamic('warningP2midLink')}{' '}
            <button onClick={onShowPrivacy} className="underline text-sky-600 hover:text-sky-700">{t_noDynamic('privacyPolicyLink')}</button>{' '}
            {t_noDynamic('warningP2postLink')}
        </p>
        <button
          onClick={onAgree}
          className="w-full bg-red-500 hover:bg-red-600 text-white font-semibold py-3 px-5 rounded-lg transition-colors uppercase"
        >
          {t_noDynamic('warningAgreeButton')}
        </button>
      </div>
    </div>
  );
};


const AppFooter = () => {
  const { t_noDynamic } = useTranslation();
  const currentYear = new Date().getFullYear();

  const handleShareApp = () => {
    if (window.Telegram && window.Telegram.WebApp) {
      const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(t_noDynamic('shareAppTextToFriend'))}`;
      window.Telegram.WebApp.openTelegramLink(shareUrl);
    } else {
      alert(t_noDynamic('shareFunctionNotAvailable'));
    }
  };


  return (
    <footer className="p-5 mt-auto text-center border-t border-sky-200/70 bg-sky-50/50 backdrop-blur-sm">
       <div className="flex justify-center items-center space-x-4 mb-3">
          <button 
            onClick={handleShareApp} 
            className="flex items-center space-x-1.5 text-xs text-sky-600 hover:text-sky-700 transition-colors"
            aria-label={t_noDynamic('shareAppButtonAriaLabel')}
          >
            <ShareIcon className="w-4 h-4" />
            <span>{t_noDynamic('shareAppButton')}</span>
          </button>
          <a 
            href="mailto:aidoktor.uz@gmail.com" 
            className="flex items-center space-x-1.5 text-xs text-sky-600 hover:text-sky-700 transition-colors"
            aria-label={t_noDynamic('feedbackButtonAriaLabel')}
          >
            <FeedbackIcon className="w-4 h-4" />
            <span>{t_noDynamic('feedbackButton')}</span>
          </a>
        </div>
      <p className="text-xs text-slate-500 mb-1">
        &copy; {currentYear} AiDoktor.uz. {t_noDynamic('footerRights')}
      </p>
      <p className="text-xs font-semibold text-sky-700 uppercase">
        {t_noDynamic('footerSlogan')}
      </p>
    </footer>
  );
};


// --- Main App Component ---
export const App = () => {
  const { t, t_noDynamic } = useTranslation();
  const [currentMode, setCurrentMode] = useState(AppMode.None);
  const [showWarning, setShowWarning] = useState(true);
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);
  const [showTermsOfUse, setShowTermsOfUse] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false); 
  const [currentUser, setCurrentUser] = useState(null); 
  const [lastActivityTime, setLastActivityTime] = useState(Date.now());
  const [isIdleModalOpen, setIsIdleModalOpen] = useState(false);

  const IDLE_TIMEOUT = 15 * 60 * 1000; // 15 minutes

  const handleBackToMain = useCallback(() => {
    setCurrentMode(AppMode.None);
  }, []);

  useEffect(() => {
    let agreed = false;
    try {
      agreed = localStorage.getItem('warningAgreed') === 'true';
    } catch (e) {
      console.warn("Could not access localStorage for 'warningAgreed':", e);
    }
    if (agreed) {
      setShowWarning(false);
    }
    
    try {
      const storedUser = localStorage.getItem('aidoktorUser');
      if (storedUser) {
          try {
              const parsedUser = JSON.parse(storedUser);
              setCurrentUser(parsedUser);
              setIsLoggedIn(true);
          } catch (e) {
              console.error("Error parsing stored user:", e);
              try {
                localStorage.removeItem('aidoktorUser');
              } catch (removeError) {
                console.warn("Could not remove corrupted 'aidoktorUser' from localStorage:", removeError);
              }
          }
      }
    } catch (e) {
        console.warn("Could not access localStorage for 'aidoktorUser':", e);
    }

    // Telegram WebApp SDK Integration
    if (window.Telegram && window.Telegram.WebApp) {
      const tg = window.Telegram.WebApp;
      tg.ready();
      tg.expand(); 

      // Updated theme colors for a light, vibrant appearance
      tg.setBackgroundColor('#f0f8ff'); // AliceBlue (matches #theme-body)
      tg.setHeaderColor('#e0f2fe');    // Light Sky Blue (sky-100)

      // If Telegram provides themeParams, try to use them, but prioritize our theme.
      // const body = document.getElementById('theme-body');
      // if (body) {
      //    body.style.backgroundColor = tg.themeParams.bg_color || '#f0f8ff'; 
      // }
      // tg.setHeaderColor(tg.themeParams.secondary_bg_color || '#e0f2fe');       
    }
  }, []);

  useEffect(() => {
    let idleTimer;

    const resetTimer = () => {
      setLastActivityTime(Date.now());
      setIsIdleModalOpen(false); 
      clearTimeout(idleTimer);
      idleTimer = setTimeout(() => {
        setIsIdleModalOpen(true);
      }, IDLE_TIMEOUT);
    };

    const handleActivity = () => resetTimer();

    window.addEventListener('mousemove', handleActivity);
    window.addEventListener('keydown', handleActivity);
    window.addEventListener('scroll', handleActivity);
    window.addEventListener('click', handleActivity);
    
    resetTimer(); 

    return () => {
      clearTimeout(idleTimer);
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('keydown', handleActivity);
      window.removeEventListener('scroll', handleActivity);
      window.removeEventListener('click', handleActivity);
    };
  }, [IDLE_TIMEOUT]);

  // Telegram BackButton Management
  useEffect(() => {
    if (window.Telegram && window.Telegram.WebApp) {
      const tg = window.Telegram.WebApp;
      const backButton = tg.BackButton;

      const onBackClick = () => {
        handleBackToMain();
      };

      if (currentMode !== AppMode.None) {
        backButton.show();
        backButton.onClick(onBackClick);
      } else {
        backButton.hide();
        backButton.offClick(onBackClick); 
      }
      
      return () => {
        if (backButton.isVisible) {
            backButton.offClick(onBackClick);
            backButton.hide();
        }
      };
    }
  }, [currentMode, handleBackToMain]);


  const handleContinueSession = () => {
    setIsIdleModalOpen(false);
    setLastActivityTime(Date.now()); 
  };

  const handleEndSession = () => {
    setIsIdleModalOpen(false);
    handleLogout(); 
  };


  const handleAgreeWarning = () => {
    try {
      localStorage.setItem('warningAgreed', 'true');
    } catch (e) {
      console.warn("Could not set 'warningAgreed' in localStorage:", e);
    }
    setShowWarning(false);
  };

  const handleModeSelect = (mode, isDisabled = false) => {
    if (showWarning || isDisabled) return;
    setCurrentMode(mode);
  };
  
  const handleLoginSuccess = (user) => {
    setIsLoggedIn(true);
    setCurrentUser(user);
    try {
      localStorage.setItem('aidoktorUser', JSON.stringify(user));
    } catch (e) {
      console.warn("Could not set 'aidoktorUser' in localStorage:", e);
    }
    setCurrentMode(AppMode.None); 
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    try {
      localStorage.removeItem('aidoktorUser');
    } catch (e) {
      console.warn("Could not remove 'aidoktorUser' from localStorage:", e);
    }
    setCurrentMode(AppMode.None); 
  };
  
  const renderCurrentMode = () => {
    switch (currentMode) {
      case AppMode.QuickDiagnosis:
        return <QuickDiagnosisMode onBack={handleBackToMain} />;
      case AppMode.ComprehensiveAnalysis:
        return <ComprehensiveAnalysisMode onBack={handleBackToMain} />;
      case AppMode.HealthLibrary:
        return <HealthLibraryMode onBack={handleBackToMain} />;
      case AppMode.Physiotherapy:
        return <PhysiotherapyMode onBack={handleBackToMain} />;
      case AppMode.CallCenter:
        return <CallCenterMode onBack={handleBackToMain} />;
      case AppMode.OnLab:
        return <OnLabMode onBack={handleBackToMain} />;
      case AppMode.DrugIdentifier:
        return <DrugIdentifierMode onBack={handleBackToMain} />;
      case AppMode.FirstAid:
        return <FirstAidMode onBack={handleBackToMain} />;
      case AppMode.Login:
        return <LoginPage 
                  onLoginSuccess={handleLoginSuccess} 
                  onNavigateToRegister={() => setCurrentMode(AppMode.Register)}
                  onBack={handleBackToMain} 
                />;
      case AppMode.Register:
        return <RegisterPage 
                  onRegisterSuccess={handleLoginSuccess} 
                  onNavigateToLogin={() => setCurrentMode(AppMode.Login)}
                  onBack={handleBackToMain} 
                />;
      case AppMode.UserCabinet:
        return <UserCabinetPage 
                  currentUser={currentUser} 
                  onLogout={handleLogout} 
                  onBack={handleBackToMain} 
                />;
      default:
        const mainMenuItems = [
          // Row 1: Top-tier (Largest) - New Light Theme
          { mode: AppMode.QuickDiagnosis, titleKey: 'quickDiagnosisButton', descKey: 'quickDiagnosisDescription', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10 md:w-12 md:h-12 mb-2.5 md:mb-3 text-teal-500"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" /></svg>, bgColor: 'bg-teal-100/70 hover:bg-teal-200/80', borderColor: 'border-teal-300/70', textColor: 'text-teal-700', descColor: 'text-teal-600', glowColor: 'rgba(20, 184, 166, 0.35)', disabled: false, row: 1 },
          { mode: AppMode.ComprehensiveAnalysis, titleKey: 'comprehensiveAnalysisButton', descKey: 'comprehensiveAnalysisDescription', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10 md:w-12 md:h-12 mb-2.5 md:mb-3 text-purple-500"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>, bgColor: 'bg-purple-100/70 hover:bg-purple-200/80', borderColor: 'border-purple-300/70', textColor: 'text-purple-700', descColor: 'text-purple-600', glowColor: 'rgba(168, 85, 247, 0.35)', disabled: false, row: 1 },
          { mode: AppMode.OnLab, titleKey: 'onLabButton', descKey: 'onLabDescription', icon: <MicroscopeIcon className="w-10 h-10 md:w-12 md:h-12 mb-2.5 md:mb-3 text-orange-500" title={t_noDynamic('onLabIconMicroscopeAlt')} />, bgColor: 'bg-orange-100/70 hover:bg-orange-200/80', borderColor: 'border-orange-300/70', textColor: 'text-orange-700', descColor: 'text-orange-600', glowColor: 'rgba(249, 115, 22, 0.35)', disabled: false, row: 1 },
          
          // Row 2: Combined secondary row (Smaller) - New Light Theme
          { mode: AppMode.FirstAid, titleKey: 'firstAidButton', descKey: 'firstAidDescription', icon: <FirstAidIcon className="w-7 h-7 md:w-8 md:h-8 mb-1.5 text-red-500" title={t_noDynamic('firstAidIconAlt')} />, bgColor: 'bg-red-100/70 hover:bg-red-200/80', textColor: 'text-red-700', descColor: 'text-red-600', glowColor: 'rgba(239, 68, 68, 0.35)', disabled: false, row: 2 },
          { mode: AppMode.DrugIdentifier, titleKey: 'drugIdentifierButton', descKey: 'drugIdentifierDescription', icon: <PillIcon className="w-7 h-7 md:w-8 md:h-8 mb-1.5 text-emerald-500" title={t_noDynamic('attentionTitle')} />, bgColor: 'bg-emerald-100/70 hover:bg-emerald-200/80', textColor: 'text-emerald-700', descColor: 'text-emerald-600', glowColor: 'rgba(16, 185, 129, 0.35)', disabled: false, row: 2 },
          { mode: AppMode.HealthLibrary, titleKey: 'healthLibraryButton', descKey: 'healthLibraryDescription', icon: <LockIcon className="w-7 h-7 md:w-8 md:h-8 mb-1.5 text-slate-500" title={t_noDynamic('featureLockedIconTitle')} />, bgColor: 'bg-slate-200/80', textColor: 'text-slate-500', descColor: 'text-slate-400', glowColor: 'rgba(107, 114, 128, 0.2)', disabled: true, isComingSoon: true, row: 2 },
          { mode: AppMode.Physiotherapy, titleKey: 'physiotherapyButton', descKey: 'physiotherapyDescription', icon: <LockIcon className="w-7 h-7 md:w-8 md:h-8 mb-1.5 text-slate-500" title={t_noDynamic('featureLockedIconTitle')} />, bgColor: 'bg-slate-200/80', textColor: 'text-slate-500', descColor: 'text-slate-400', glowColor: 'rgba(236, 72, 153, 0.2)', disabled: true, isComingSoon: true, row: 2 }
        ];
        
        const callCenterItem = { 
            mode: AppMode.CallCenter, 
            titleKey: 'callCenterButton', 
            descKey: 'callCenterDescription', 
            icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-9 h-9 md:w-10 md:h-10 mb-2 text-white"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" /></svg>,
            bgColor: 'bg-gradient-to-r from-sky-500 to-blue-500 hover:from-sky-600 hover:to-blue-600', 
            textColor: 'text-white', 
            descColor: 'text-sky-100',
            glowColor: 'rgba(14, 165, 233, 0.45)' // sky-500
        };

        const renderMenuItem = (item) => {
            const baseClasses = `main-menu-button flex flex-col items-center justify-center rounded-xl shadow-lg disabled:cursor-not-allowed text-center backdrop-blur-sm`;
            let specificClasses = "";
            let titleClasses = `text-center uppercase`;
            let descriptionClasses = `text-center`;
            
            if (item.row === 1) { // Top Row - Largest
              specificClasses = `${item.bgColor} p-5 md:p-8 min-h-[220px] md:min-h-[280px] border ${item.borderColor || 'border-transparent'}`;
              if (item.disabled) specificClasses = `bg-slate-200/70 opacity-70 p-5 md:p-8 min-h-[220px] md:min-h-[280px] border border-slate-300/50`;
              titleClasses += ` text-xl md:text-2xl font-bold mb-2 md:mb-3 ${item.textColor || 'text-slate-800'}`; 
              descriptionClasses += ` text-base md:text-lg ${item.descColor || 'text-slate-600'}`;
            } else if (item.row === 2) { // New Combined Secondary Row - Smaller
              specificClasses = `${item.bgColor} p-3 md:p-4 min-h-[150px] md:min-h-[170px] border ${item.borderColor || 'border-transparent'}`; 
              if (item.disabled) specificClasses = `bg-slate-200/70 opacity-70 p-3 md:p-4 min-h-[150px] md:min-h-[170px] border border-slate-300/50`;
              titleClasses += ` text-base md:text-lg font-semibold mb-1 ${item.textColor || 'text-slate-700'}`;
              descriptionClasses += ` text-xs md:text-sm ${item.descColor || 'text-slate-500'}`;
            }
            
            return (
                <button
                    key={item.mode}
                    onClick={() => handleModeSelect(item.mode, item.disabled)}
                    disabled={showWarning || item.disabled}
                    className={`${baseClasses} ${specificClasses}`}
                    style={{ '--glow-color': item.glowColor } as React.CSSProperties}
                    aria-label={t_noDynamic(item.titleKey)}
                >
                    {item.icon}
                    <h3 className={titleClasses}>{t_noDynamic(item.titleKey)}</h3>
                    <p className={descriptionClasses}>{t_noDynamic(item.descKey)}</p>
                    {item.isComingSoon && (
                    <span className="text-xs text-yellow-600 mt-1 uppercase">{t_noDynamic(item.disabled ? 'featureLockedIconTitle' : 'featureComingSoonShort')}</span>
                    )}
                </button>
            );
        };


        return (
          <div className="flex-grow flex flex-col items-center justify-center p-4 md:p-6 text-center">
            <div className="bg-white/60 backdrop-blur-lg p-5 md:p-8 rounded-xl shadow-2xl max-w-4xl w-full">
              <h1 className="text-3xl md:text-4xl font-bold mb-3 text-slate-800">{t_noDynamic('appTitle')}</h1>
              <p className="text-md md:text-lg mb-6 text-slate-600">{t_noDynamic('appSubtitle')}</p>
              
               {/* Central Start Button */}
              <button
                onClick={() => handleModeSelect(AppMode.QuickDiagnosis)}
                disabled={showWarning}
                className="w-full max-w-lg mx-auto flex items-center justify-center space-x-3 p-4 mb-8 rounded-xl shadow-xl
                           bg-gradient-to-r from-green-400 to-teal-400 hover:from-green-500 hover:to-teal-500 
                           text-white text-xl md:text-2xl font-bold uppercase transition-all transform hover:scale-105 focus:ring-4 focus:ring-green-300/40"
                aria-label={t_noDynamic('startDiagnosisButton')}
              >
                <StartIcon className="w-8 h-8 md:w-10 md:h-10" />
                <span>{t_noDynamic('startDiagnosisButton')}</span>
              </button>

              <AdPlaceholder 
                adType="banner_728x90" 
                className="mb-8"
                titleText={t_noDynamic('adPlaceholderMainMenu')}
              />

              {/* Row 1 (Top-tier) */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-8 mb-6 md:mb-8">
                {mainMenuItems.filter(item => item.row === 1).map(renderMenuItem)}
              </div>

              {/* Row 2 (New Combined Secondary Row) */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-5 mb-6 md:mb-8"> 
                 {mainMenuItems.filter(item => item.row === 2).map(renderMenuItem)}
              </div>
                            
              <button
                  key={callCenterItem.mode}
                  onClick={() => handleModeSelect(callCenterItem.mode)}
                  disabled={showWarning}
                  className={`main-menu-button call-center-button w-full flex flex-col items-center justify-center p-5 md:p-6 rounded-xl shadow-lg disabled:opacity-60 disabled:cursor-not-allowed min-h-[110px] md:min-h-[130px] mt-4 ${callCenterItem.bgColor}`}
                  style={{ '--glow-color': callCenterItem.glowColor } as React.CSSProperties}
                  aria-label={t_noDynamic(callCenterItem.titleKey)}
                >
                  <div className="flex flex-col items-center sm:flex-row sm:items-center">
                    {callCenterItem.icon}
                    <div className="mt-2 sm:mt-0 sm:ml-4 text-center sm:text-left">
                      <h3 className={`text-xl md:text-2xl font-semibold uppercase ${callCenterItem.textColor}`}>{t_noDynamic(callCenterItem.titleKey)}</h3>
                      <p className={`text-sm md:text-base ${callCenterItem.descColor}`}>{t_noDynamic(callCenterItem.descKey)}</p>
                    </div>
                  </div>
              </button>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="flex flex-col min-h-screen text-slate-800"> {/* Main text color updated */}
      {showWarning && (
        <WarningModal 
          onAgree={handleAgreeWarning} 
          onShowPrivacy={() => setShowPrivacyPolicy(true)}
          onShowTerms={() => setShowTermsOfUse(true)}
        />
      )}
      {showPrivacyPolicy && <PrivacyPolicyModal onClose={() => setShowPrivacyPolicy(false)} />}
      {showTermsOfUse && <TermsOfUseModal onClose={() => setShowTermsOfUse(false)} />}

      {isIdleModalOpen && (
        <div id="idleModalContainer" className="fixed inset-0 bg-black/50 backdrop-blur-md flex items-center justify-center z-[60] p-4 animate-fadeInScaleUp" role="dialog" aria-modal="true" aria-labelledby="idleModalTitle">
          <div className="bg-white/95 backdrop-blur-sm p-6 rounded-xl shadow-xl max-w-sm w-full text-center max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="flex justify-center mb-4">
              <IdleTimerIcon className="w-12 h-12 text-amber-500" title={t_noDynamic('attentionTitle')} />
            </div>
            <h2 id="idleModalTitle" className="text-xl font-semibold text-amber-600 mb-3 uppercase">{t_noDynamic('attentionTitle')}</h2>
            <p className="text-slate-600 mb-6 text-sm">{t_noDynamic('idleSessionPrompt')}</p>
            <div className="flex flex-col sm:flex-row justify-center space-y-3 sm:space-y-0 sm:space-x-3">
              <button 
                onClick={handleContinueSession} 
                className="py-2 px-4 bg-green-500 hover:bg-green-600 text-white rounded-md text-sm uppercase w-full sm:w-auto"
              >
                {t_noDynamic('idleContinueButton')}
              </button>
              <button 
                onClick={handleEndSession} 
                className="py-2 px-4 bg-red-500 hover:bg-red-600 text-white rounded-md text-sm uppercase w-full sm:w-auto"
              >
                {t_noDynamic('idleEndButton')}
              </button>
            </div>
          </div>
        </div>
      )}

      {!showWarning && (
          <Header 
            currentMode={currentMode} 
            isLoggedIn={isLoggedIn} 
            currentUser={currentUser}
            onLoginClick={() => handleModeSelect(AppMode.Login)}
            onLogoutClick={handleLogout}
            onUserCabinetClick={() => handleModeSelect(AppMode.UserCabinet)}
        />
      )}
      <main className={`flex-grow flex flex-col ${currentMode === AppMode.None ? 'justify-center' : ''} p-2 sm:p-4 md:p-6`}>
        {renderCurrentMode()}
      </main>
      {!showWarning && <AppFooter />}
    </div>
  );
};
